/*
 * Library Management System
 * Student: Emmanuel Gyamfi | Index number: PS/ITC/24/0317
 * Core data structure: JavaScript arrays of book objects.
 * This is a client-side demonstration. Data persists in this browser via localStorage.
 */
'use strict';

const STORAGE_KEY = 'libra-library-books-v1';
const ACTIVITY_KEY = 'libra-library-activity-v1';

const starterBooks = [
  { id: 'B001', title: 'Things Fall Apart', author: 'Chinua Achebe', isbn: '9780385474542', category: 'Fiction', year: 1958, borrowed: false, borrower: '' },
  { id: 'B002', title: 'Clean Code', author: 'Robert C. Martin', isbn: '9780132350884', category: 'Computing', year: 2008, borrowed: false, borrower: '' },
  { id: 'B003', title: 'Introduction to Algorithms', author: 'Thomas H. Cormen', isbn: '9780262046305', category: 'Computing', year: 2022, borrowed: true, borrower: 'Sample Student' },
  { id: 'B004', title: 'A Brief History of Time', author: 'Stephen Hawking', isbn: '9780553380163', category: 'Science', year: 1998, borrowed: false, borrower: '' },
  { id: 'B005', title: 'The Lean Startup', author: 'Eric Ries', isbn: '9780307887894', category: 'Business', year: 2011, borrowed: true, borrower: 'Ama Mensah' },
  { id: 'B006', title: 'How to Win Friends and Influence People', author: 'Dale Carnegie', isbn: '9780671027032', category: 'Education', year: 1936, borrowed: false, borrower: '' },
  { id: 'B007', title: 'The River Between', author: 'Ngũgĩ wa Thiong’o', isbn: '9780435905484', category: 'Fiction', year: 1965, borrowed: false, borrower: '' }
];

function loadJSON(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (error) {
    console.warn(`Could not read ${key} from local storage.`, error);
    return fallback;
  }
}

// The catalogue is an array; array operations drive the main application.
let books = loadJSON(STORAGE_KEY, starterBooks.map(book => ({ ...book })));
let activities = loadJSON(ACTIVITY_KEY, []);
let toastTimer = null;

const el = id => document.getElementById(id);
const form = el('bookForm');
const titleInput = el('bookTitle');
const authorInput = el('bookAuthor');
const isbnInput = el('bookIsbn');
const categoryInput = el('bookCategory');
const yearInput = el('bookYear');

function saveData() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(books));
    localStorage.setItem(ACTIVITY_KEY, JSON.stringify(activities.slice(0, 8)));
  } catch (error) {
    console.error('Unable to save library data in this browser.', error);
    showToast('Could not save data. Check your browser storage settings.');
  }
}

function showToast(message) {
  const toast = el('toast');
  toast.textContent = message;
  toast.classList.add('show');
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => toast.classList.remove('show'), 2800);
}

function escapeHTML(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[char]));
}

function makeId() {
  // Use a short unique ID that remains compatible with older browsers.
  return `B${Date.now().toString(36).toUpperCase()}${Math.random().toString(36).slice(2, 5).toUpperCase()}`;
}

function addActivity(action, message, icon = '•') {
  activities.unshift({ id: makeId(), action, message, icon, time: new Date().toISOString() });
  activities = activities.slice(0, 8);
}

function formatRelativeTime(iso) {
  const seconds = Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));
  if (seconds < 60) return 'Just now';
  if (seconds < 3600) return `${Math.floor(seconds / 60)} min ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)} hr ago`;
  return `${Math.floor(seconds / 86400)} day(s) ago`;
}

function renderStats() {
  const borrowed = books.filter(book => book.borrowed).length;
  const available = books.filter(book => !book.borrowed).length;
  // Set collects unique category names; the list is derived from the books array.
  const categories = new Set(books.map(book => book.category.trim()).filter(Boolean));
  el('totalCount').textContent = books.length;
  el('availableCount').textContent = available;
  el('borrowedCount').textContent = borrowed;
  el('categoryCount').textContent = categories.size;
}

function renderCategoryFilters() {
  const categoryFilter = el('categoryFilter');
  const previous = categoryFilter.value || 'all';
  // map() obtains categories, filter() removes duplicates, and sort() orders them.
  const categories = [...new Set(books.map(book => book.category).filter(Boolean))].sort((a, b) => a.localeCompare(b));
  categoryFilter.innerHTML = '<option value="all">All categories</option>' + categories.map(category =>
    `<option value="${escapeHTML(category)}">${escapeHTML(category)}</option>`
  ).join('');
  categoryFilter.value = categories.includes(previous) ? previous : 'all';

  // Keep the entry form's category list current when a user adds a new category.
  const formSelected = categoryInput.value;
  const defaultOptions = ['Computing', 'Fiction', 'Science', 'Education', 'History', 'Business', 'Other'];
  const formCategories = [...new Set([...defaultOptions, ...categories])].sort((a, b) => a.localeCompare(b));
  categoryInput.innerHTML = '<option value="">Select a category</option>' + formCategories.map(category =>
    `<option value="${escapeHTML(category)}">${escapeHTML(category)}</option>`
  ).join('');
  if (formCategories.includes(formSelected)) categoryInput.value = formSelected;
}

function filteredBooks() {
  const term = el('searchInput').value.trim().toLowerCase();
  const status = el('statusFilter').value;
  const category = el('categoryFilter').value;
  // filter() selects visible results; some() checks text across searchable fields.
  return books.filter(book => {
    const matchesTerm = !term || [book.title, book.author, book.isbn, book.category].some(value => String(value || '').toLowerCase().includes(term));
    const matchesStatus = status === 'all' || (status === 'borrowed' ? book.borrowed : !book.borrowed);
    const matchesCategory = category === 'all' || book.category === category;
    return matchesTerm && matchesStatus && matchesCategory;
  });
}

function renderBooks() {
  const visibleBooks = filteredBooks();
  const tbody = el('bookTableBody');
  const colours = ['cover-0', 'cover-1', 'cover-2', 'cover-3', 'cover-4'];
  tbody.innerHTML = visibleBooks.map((book, index) => {
    const letter = escapeHTML((book.title.trim()[0] || 'B').toUpperCase());
    const coverClass = colours[(index + (book.title.length % colours.length)) % colours.length];
    const statusClass = book.borrowed ? 'borrowed' : 'available';
    const statusLabel = book.borrowed ? 'Borrowed' : 'Available';
    const mainAction = book.borrowed
      ? `<button class="action-button borrow" data-action="return" data-id="${escapeHTML(book.id)}" title="Return this book">Return</button>`
      : `<button class="action-button borrow" data-action="borrow" data-id="${escapeHTML(book.id)}" title="Borrow this book">Borrow</button>`;
    return `<tr>
      <td><div class="book-detail"><div class="book-cover ${coverClass}">${letter}</div><div><div class="book-title" title="${escapeHTML(book.title)}">${escapeHTML(book.title)}</div><div class="book-author">${escapeHTML(book.author)}</div></div></div></td>
      <td>${escapeHTML(book.isbn || '—')}</td>
      <td><span class="category-tag">${escapeHTML(book.category)}</span></td>
      <td><span class="status ${statusClass}">${statusLabel}</span></td>
      <td><div class="actions">${mainAction}<button class="action-button" data-action="edit" data-id="${escapeHTML(book.id)}" title="Edit book" aria-label="Edit ${escapeHTML(book.title)}">✎</button><button class="action-button delete" data-action="delete" data-id="${escapeHTML(book.id)}" title="Delete book" aria-label="Delete ${escapeHTML(book.title)}">×</button></div></td>
    </tr>`;
  }).join('');
  el('emptyState').hidden = visibleBooks.length > 0;
  tbody.hidden = visibleBooks.length === 0;
  el('resultCount').textContent = `Showing ${visibleBooks.length} of ${books.length} book${books.length === 1 ? '' : 's'}`;
}

function renderActivities() {
  const list = el('activityList');
  list.innerHTML = activities.map(item => `<li class="activity-item"><span class="activity-marker" aria-hidden="true">${escapeHTML(item.icon || '•')}</span><div><strong>${escapeHTML(item.action)}</strong><p>${escapeHTML(item.message)}</p><span class="activity-time">${formatRelativeTime(item.time)}</span></div></li>`).join('');
  el('activityEmpty').hidden = activities.length > 0;
  list.hidden = activities.length === 0;
}

function render() {
  renderStats();
  renderCategoryFilters();
  renderBooks();
  renderActivities();
}

function resetForm() {
  form.reset();
  el('bookId').value = '';
  el('formTitle').textContent = 'Add a book';
  el('saveBookButton').textContent = 'Save book';
  el('bookYear').value = '';
}

function openForm(book = null) {
  if (book) {
    el('bookId').value = book.id;
    titleInput.value = book.title;
    authorInput.value = book.author;
    isbnInput.value = book.isbn || '';
    renderCategoryFilters();
    categoryInput.value = book.category;
    yearInput.value = book.year || '';
    el('formTitle').textContent = 'Edit book';
    el('saveBookButton').textContent = 'Update book';
  } else {
    resetForm();
  }
  el('bookFormPanel').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  window.setTimeout(() => titleInput.focus({ preventScroll: true }), 250);
}

function handleSaveBook(event) {
  event.preventDefault();
  const title = titleInput.value.trim();
  const author = authorInput.value.trim();
  const isbn = isbnInput.value.trim();
  const category = categoryInput.value;
  const year = yearInput.value ? Number(yearInput.value) : '';
  const existingId = el('bookId').value;
  if (!title || !author || !category) {
    showToast('Please complete the required fields.');
    return;
  }
  if (year && (!Number.isInteger(year) || year < 1450 || year > 2100)) {
    showToast('Enter a valid publication year.');
    yearInput.focus();
    return;
  }
  // Prevent accidental duplicates where the same non-empty ISBN is entered twice.
  const duplicateIsbn = isbn && books.some(book => book.isbn && book.isbn.toLowerCase() === isbn.toLowerCase() && book.id !== existingId);
  if (duplicateIsbn) {
    showToast('A book with this ISBN is already in the catalogue.');
    isbnInput.focus();
    return;
  }
  if (existingId) {
    const index = books.findIndex(book => book.id === existingId);
    if (index === -1) {
      showToast('That book could not be found. Refresh and try again.');
      return;
    }
    // Replace one element at its array index while preserving borrowing status.
    books[index] = { ...books[index], title, author, isbn, category, year };
    addActivity('Book updated', `Updated “${title}”.`, '✎');
    showToast('Book details updated.');
  } else {
    books.unshift({ id: makeId(), title, author, isbn, category, year, borrowed: false, borrower: '' });
    addActivity('Book added', `Added “${title}” by ${author}.`, '+');
    showToast('Book added to the catalogue.');
  }
  saveData();
  resetForm();
  render();
}

function borrowBook(book) {
  if (book.borrowed) return;
  const borrower = window.prompt(`Who is borrowing “${book.title}”?`, 'Student');
  if (borrower === null) return;
  const name = borrower.trim();
  if (!name) {
    showToast('Enter a borrower name to continue.');
    return;
  }
  const record = books.find(item => item.id === book.id);
  if (!record || record.borrowed) return;
  record.borrowed = true;
  record.borrower = name;
  addActivity('Book borrowed', `“${record.title}” borrowed by ${name}.`, '↗');
  saveData();
  render();
  showToast('Book marked as borrowed.');
}

function returnBook(book) {
  if (!book.borrowed) return;
  const record = books.find(item => item.id === book.id);
  if (!record) return;
  const borrower = record.borrower;
  record.borrowed = false;
  record.borrower = '';
  addActivity('Book returned', `“${record.title}” returned${borrower ? ` by ${borrower}` : ''}.`, '✓');
  saveData();
  render();
  showToast('Book marked as available.');
}

function handleTableAction(event) {
  const button = event.target.closest('button[data-action]');
  if (!button) return;
  const book = books.find(item => item.id === button.dataset.id);
  if (!book) return;
  switch (button.dataset.action) {
    case 'borrow': borrowBook(book); break;
    case 'return': returnBook(book); break;
    case 'edit': openForm(book); break;
    case 'delete':
      if (!window.confirm(`Delete “${book.title}” from the catalogue? This cannot be undone.`)) return;
      // splice() removes the matching record from the books array.
      books.splice(books.findIndex(item => item.id === book.id), 1);
      addActivity('Book deleted', `Removed “${book.title}” from the catalogue.`, '×');
      if (el('bookId').value === book.id) resetForm();
      saveData();
      render();
      showToast('Book removed from the catalogue.');
      break;
    default: break;
  }
}

function exportCSV() {
  if (books.length === 0) {
    showToast('There are no books to export.');
    return;
  }
  const columns = ['id', 'title', 'author', 'isbn', 'category', 'year', 'status', 'borrower'];
  const csvValue = value => `"${String(value ?? '').replace(/"/g, '""')}"`;
  const lines = [columns.map(csvValue).join(',')];
  books.forEach(book => {
    const values = [book.id, book.title, book.author, book.isbn, book.category, book.year, book.borrowed ? 'Borrowed' : 'Available', book.borrower];
    lines.push(values.map(csvValue).join(','));
  });
  const blob = new Blob(['\uFEFF' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'library-books.csv';
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
  showToast('CSV export created.');
}

// Event listeners keep interactions separated from rendering logic.
form.addEventListener('submit', handleSaveBook);
el('addBookTop').addEventListener('click', () => openForm());
el('emptyAddBook').addEventListener('click', () => openForm());
el('closeForm').addEventListener('click', () => { resetForm(); showToast('Form closed.'); });
el('cancelEdit').addEventListener('click', resetForm);
el('bookTableBody').addEventListener('click', handleTableAction);
el('searchInput').addEventListener('input', renderBooks);
el('statusFilter').addEventListener('change', renderBooks);
el('categoryFilter').addEventListener('change', renderBooks);
el('exportCsv').addEventListener('click', exportCSV);

// Repaint relative timestamps when the page is revisited.
render();
