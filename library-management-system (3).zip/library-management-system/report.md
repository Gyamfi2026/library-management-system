# Assignment Report: Library Management System Using Arrays

**Student name:** Emmanuel Gyamfi  
**Index number:** PS/ITC/24/0317  
**Chosen application:** Library Management System  
**Technologies:** HTML, CSS, JavaScript, browser local storage, GitHub Pages

## 1. Introduction

Data structures are methods of organising and storing data so that a computer program can access and modify it efficiently. Arrays are a common data structure because they hold multiple values in an ordered collection. This project describes real-world applications of arrays and develops a small Library Management System to demonstrate how an array can manage a book catalogue.

## 2. Real-world applications that use arrays

1. **Library catalogue:** An array can store book records and support listing, searching, adding, editing, and removing books.
2. **Student results system:** An array can hold marks or student records, allowing a program to calculate totals, averages, highest marks, and class rankings.
3. **Online shopping cart:** An array can hold the items a customer intends to purchase and update quantities or remove products.
4. **Hospital appointment schedule:** An array can represent appointments in a day, making it possible to display appointments in order and locate open slots.
5. **Inventory management:** An array can hold product records and stock quantities, making stock searching and updating straightforward.
6. **Music playlist:** An array can preserve the order of tracks and allow a player to move to the next or previous track.
7. **Bank transaction history:** An array can store an ordered list of recent transaction records for display and review.

## 3. Why arrays are useful

Arrays group related values under one variable instead of requiring a separate variable for each record. They are ordered, can be traversed with loops or array methods, and make operations such as searching, filtering, sorting, and adding elements convenient. In JavaScript, arrays can store objects, so each book can contain several related fields such as title, author, ISBN, category, publication year, and borrowing status.

Arrays do have limitations. Finding a record in an unsorted array may require checking each item, and deleting or inserting an item in the middle can require shifting elements. For a small educational catalogue, however, the simplicity of arrays is useful. A large production system may use a database and additional indexes instead.

## 4. Selected application: Library Management System

The Library Management System was selected because libraries manage collections of related book records and regularly search, add, update, borrow, and return books. These tasks provide clear examples of array operations.

### Objectives

- Store several book records in one collection.
- Display the total, available, and borrowed book counts.
- Search the collection by title, author, ISBN, or category.
- Filter books by category and borrowing status.
- Add new books and edit or remove existing records.
- Mark a book as borrowed or returned.
- Demonstrate JavaScript array methods in a working interface.

### Main data structure

The core `books` variable in `script.js` is an array of objects. A simplified record looks like this:

```javascript
{
  id: "B001",
  title: "Things Fall Apart",
  author: "Chinua Achebe",
  isbn: "9780385474542",
  category: "Fiction",
  year: 1958,
  borrowed: false,
  borrower: ""
}
```

Each object represents one book, and the array stores all of the records. An `id` identifies each record when it is edited, borrowed, returned, or deleted.

## 5. How array operations are used

| Array operation | How the application uses it |
|---|---|
| `filter()` | Finds the books matching the search term, status, or selected category; also counts borrowed and available books. |
| `map()` | Converts book and activity records into interface elements and extracts category names. |
| `find()` | Locates an individual book when an action is selected. |
| `findIndex()` | Finds the position of a record to update or remove it. |
| `some()` | Checks whether a search term appears in the searchable fields and checks for duplicate ISBNs. |
| `unshift()` | Adds a new book to the beginning of the catalogue and puts recent activity at the top of the activity list. |
| `splice()` | Removes a selected book from the array. |
| `sort()` | Sorts category names alphabetically for the filter menu. |
| `Set` with array values | Removes duplicate category names when calculating the category count and building filters. |

For example, the following code obtains all currently available books:

```javascript
const availableBooks = books.filter(book => !book.borrowed);
```

The program stores its records in `localStorage` so that the same browser can retain changes after a page refresh. The array is still the main in-memory data structure used by the application's logic.

## 6. System features and user interface

The dashboard displays summary counts. The catalogue provides search and filters alongside actions to borrow, return, edit, or delete a book. A form captures the title, author, ISBN, category, and publication year. Recent activity provides a simple record of catalogue actions, and CSV export allows the book list to be downloaded for further inspection.

The interface is responsive and can be used on a desktop or mobile browser. The starter catalogue contains sample records to make the demonstration useful immediately; these records can be edited or deleted.

## 7. Testing plan

| Test | Action | Expected result |
|---|---|---|
| Initial display | Open `index.html` | Sample books and correct dashboard counts appear. |
| Search | Search for a title or author | Only matching catalogue records appear. |
| Filter | Choose “Borrowed” | Only borrowed books appear. |
| Add | Enter valid details and save | A new available book appears and totals update. |
| Duplicate ISBN | Add a second book with an existing ISBN | The application prevents the duplicate. |
| Borrow | Click Borrow and enter a borrower's name | Status becomes Borrowed and the borrowed count increases. |
| Return | Click Return on a borrowed item | Status becomes Available and counts update. |
| Edit | Change a book's title or category | The updated details are shown. |
| Delete | Confirm deletion | The book is removed from the catalogue. |
| Persistence | Refresh the browser after a change | Saved records remain in that browser. |
| CSV export | Click Export CSV | A `library-books.csv` file is generated. |

## 8. Limitations and future improvements

This version is a client-side learning project and uses browser local storage. It does not synchronise across devices, and it does not provide authentication, staff/member permissions, due dates, overdue fees, a shared server database, or backups. Future improvements could include a Java or Node.js backend, a MySQL database, user accounts, borrowing deadlines, notifications, and automated testing.

## 9. Conclusion

The Library Management System demonstrates how arrays can represent and manage a real collection of records. JavaScript array methods help search, filter, display, update, and remove books with readable code. This project shows why arrays are an effective starting point for small catalogue applications while also recognising that larger systems may need a database-backed architecture.
