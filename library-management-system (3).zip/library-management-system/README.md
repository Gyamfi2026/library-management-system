# Library Management System

**Student:** Emmanuel Gyamfi  
**Index number:** PS/ITC/24/0317  
**Project topic:** A real-world application of arrays as a data structure

A responsive, browser-based Library Management System built with HTML, CSS, and vanilla JavaScript. The application's book catalogue is an array of objects, making it a practical demonstration of array operations in a real-world scenario.

## Features

- Dashboard with total books, available books, borrowed books, and category counts.
- Search by title, author, ISBN, or category.
- Filter the catalogue by availability and category.
- Add, edit, and delete book records.
- Borrow and return books, recording a borrower's name.
- Recent activity log.
- Export the catalogue as a CSV file.
- Saves catalogue and activity data in browser `localStorage`.
- Responsive layout for desktop, tablet, and mobile.

## Project files

```text
library-management-system/
├── index.html     # Application page and interface
├── style.css      # Responsive styling
├── script.js      # Catalogue logic and array operations
├── README.md      # This file and deployment instructions
├── report.md      # Written assignment report
└── .nojekyll      # GitHub Pages helper file
```

## Run locally

1. Download or clone this repository.
2. Open `index.html` in a modern browser. No package installation or build step is required.
3. Add or edit books to test the system. Data is saved in the current browser only.

## Deploy with GitHub Pages

1. Upload all project files to the **root** of the repository `Gyamfi2026/library-management-system`.
2. On GitHub, open the repository and choose **Settings**.
3. Select **Pages** from the left menu.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/(root)`, then save.
6. Wait for GitHub Pages to publish the site. The expected address is `https://gyamfi2026.github.io/library-management-system/` if Pages is enabled for that repository.

If the page does not appear, check the Actions/Pages status and confirm that `index.html` exists in the selected branch and folder. Publishing can take a few minutes after a new deployment.

## Data and limitations

This is a student demonstration, not a production library system. Records are stored in the browser's local storage rather than in a shared database, so records do not automatically synchronise between devices or browsers. There are no accounts, server-side permissions, due-date reminders, or multi-user controls. Do not enter sensitive personal information.

## Learning outcomes

The code demonstrates arrays and their methods, including `map()`, `filter()`, `find()`, `findIndex()`, `some()`, `push()`/`unshift()`, `splice()`, and `sort()`. These operations make it easier to display, search, add, edit, borrow, return, and remove books.
